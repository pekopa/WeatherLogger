<?php

$APPID = '6a050771ca054dc54c7afc56c2e5dbbc';

?>