# WeatherLogger
Measuring weather and sending it's data to the web.
